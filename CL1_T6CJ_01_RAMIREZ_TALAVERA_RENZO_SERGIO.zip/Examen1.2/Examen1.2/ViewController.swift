//
//  ViewController.swift
//  Examen1.2
//
//  Created by Renzo on 02/05/21.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var tfMenu: UITextField!
    @IBOutlet weak var tfPrecio: UITextField!
    @IBOutlet weak var tfCantidad: UITextField!
    @IBOutlet weak var tfTotal: UITextField!
    @IBOutlet weak var tfDescuento: UITextField!
    @IBOutlet weak var tfTotalPagar: UITextField!
    
    @IBOutlet weak var swDelivery: UISwitch!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
     
    var numero = 0
    
    func Limpiar(){
        tfMenu.text = ""
        tfPrecio.text = ""
        tfCantidad.text = ""
        tfTotal.text = ""
        tfDescuento.text = ""
        tfTotalPagar.text = ""
        
    }
    
    func Calcular(){
        var Precio:Double = 0.0
        var Cantidad:Int = 0
        var Total:Double = 0.0
        var Delivery:Bool = true
        var Descuento:Double = 0.0
        var TotalPagar:Double = 0.0
        
        Precio = Double(tfPrecio.text ?? "") ?? 0.0
        Cantidad = Int(tfCantidad.text ?? "") ?? 0
        Total = Double(tfTotal.text ?? "") ?? 0.0
        Delivery = swDelivery.isOn
        Descuento = Double(tfDescuento.text ?? "") ?? 0.0
        TotalPagar = Double(tfTotalPagar.text ?? "") ?? 0.0
        
        Total = (Precio * Double(Cantidad))
        
        tfTotal.text = String(Total)
        
        if Total>40 {
           Descuento = (Total * 0.05)
        }
        
        
        if(Delivery == true){
           numero = 7
        }
        else if(Delivery == false)
        {
            numero = 0
        }
            
        
        
        tfDescuento.text = String(Descuento)
        
        TotalPagar = ((Total + Double(numero)) - Descuento)
        tfTotalPagar.text = String(TotalPagar)
        
        
    }

    @IBAction func btnCalcular(_ sender: Any) {
        Calcular()
        
        if(swDelivery.isOn)
        {
            print("Si hay delivery")
        }
        else if(!swDelivery.isOn)
        {
            print("No hay delivery")
        }
    }
    
    @IBAction func btnLimpiar(_ sender: Any) {
        Limpiar()
    }
}

