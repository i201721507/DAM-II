//
//  MenuOffice.swift
//  Examen1.2
//
//  Created by Renzo on 02/05/21.
//

import UIKit

class MenuOffice: NSObject {

    var Menu:String = ""
    var Precio:Double = 0.0
    var Cantidad:Int = 0
    
    init(pMenu: String, pPrecio:Double, pCantidad:Int) {
        self.Menu = pMenu
        self.Precio = pPrecio
        self.Cantidad = pCantidad
    }
    
    func Total() -> Double{
        var tol:Double = 0.0
        tol = (self.Precio * Double(self.Cantidad))
        return tol
    }
    
    func Delivery() -> Bool{
        var deli:Bool = true
        deli = (7 != 0)
        return deli
    }
    
    func Descuento() -> Bool {
        var des:Bool = true
        des = (Total()>40 / 0.05)
        return des
    }
}
