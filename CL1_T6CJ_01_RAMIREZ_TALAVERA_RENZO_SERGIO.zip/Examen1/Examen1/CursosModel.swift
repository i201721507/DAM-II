//
//  CursosModel.swift
//  Ejercicio 1
//
//  Created by Renzo on 02/05/21.
//

import UIKit

class CursosModel: NSObject {
    
    var Nombre: String = ""
    var Apellido: String = ""
    var Dni: String = ""
    var Curso: String = ""
    var Precio: String = ""
    var Descuento: String = ""
    var Neto: String = ""
    
    override init() {
        self.Nombre = ""
        self.Apellido = ""
        self.Dni = ""
        Curso = ""
        Precio = ""
        Descuento = ""
        Neto = ""
    }
    
    init(pNombre:String, pApellido:String, pDni:String, pCurso: String, pPrecio: String, pDescuento: String, pNeto:String) {
        self.Nombre = pNombre
        self.Apellido = pApellido
        self.Dni = pDni
        self.Curso = pCurso
        self.Precio = pPrecio
        self.Descuento = pDescuento
        self.Neto = pNeto
    }
}
