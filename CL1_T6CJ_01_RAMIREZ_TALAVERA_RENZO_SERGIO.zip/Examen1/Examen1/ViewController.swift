//
//  ViewController.swift
//  Ejercicio 1
//
//  Created by Renzo on 02/05/21.
//

import UIKit

class ViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate{
    
    
    @IBOutlet weak var pvListaCurso: UIPickerView!
    
    @IBOutlet weak var tfNombre: UITextField!
    @IBOutlet weak var tfApellido: UITextField!
    @IBOutlet weak var tfDni: UITextField!
    
    
    @IBOutlet weak var lblCursoSeleccionado: UILabel!
    @IBOutlet weak var lblPrecioMostrar: UILabel!
    @IBOutlet weak var lblDescuentoMostrar: UILabel!
    @IBOutlet weak var lblNetoMostrar: UILabel!
    
    var oListaCurso: [CursosModel] = []
    var oCurso:CursosModel = CursosModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        pvListaCurso.dataSource = self
        pvListaCurso.delegate = self
        oListaCurso.append(CursosModel(pNombre: "", pApellido: "", pDni: "", pCurso: "Flutter", pPrecio: "229", pDescuento: "20.00",pNeto: "191.75"))
        oListaCurso.append(CursosModel(pNombre: "", pApellido: "", pDni: "", pCurso: "Android", pPrecio: "100.00", pDescuento: "20.00",pNeto: "115.00"))
        oListaCurso.append(CursosModel(pNombre: "", pApellido: "", pDni: "", pCurso: "IOS", pPrecio: "180.00", pDescuento: "30.00",pNeto: "192.00"))
    }

    @IBAction func btnImprimir(_ sender: Any) {
        
        var oCurso:CursosModel = CursosModel(pNombre: self.tfNombre.text!, pApellido: self.tfApellido.text!, pDni: self.tfDni.text!, pCurso: self.lblCursoSeleccionado.text!, pPrecio: self.lblPrecioMostrar.text!, pDescuento: self.lblDescuentoMostrar.text!, pNeto: self.lblNetoMostrar.text!)
        
        var osb: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let oPantalla2 = osb.instantiateViewController(identifier: "ViewControllerImprimir") as! ViewControllerImprimir
        oPantalla2.pCurso = oCurso
        
        self.present(oPantalla2, animated: true, completion: nil)
            
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return oListaCurso.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return oListaCurso[row].Curso
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        oCurso = oListaCurso[row]
        lblCursoSeleccionado.text = oCurso.Curso
        lblPrecioMostrar.text = oCurso.Precio
        lblDescuentoMostrar.text = oCurso.Descuento
        lblNetoMostrar.text = oCurso.Neto
    }
    
}

