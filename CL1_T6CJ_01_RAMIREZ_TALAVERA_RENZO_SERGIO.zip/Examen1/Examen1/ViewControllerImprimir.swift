//
//  ViewControllerImprimir.swift
//  Ejercicio 1
//
//  Created by Renzo on 02/05/21.
//

import UIKit

class ViewControllerImprimir: UIViewController {
    
    var pCurso: CursosModel = CursosModel()
    
    @IBOutlet weak var tfNombre: UITextField!
    @IBOutlet weak var tfApellido: UITextField!
    @IBOutlet weak var tfDni: UITextField!
    @IBOutlet weak var tfCurso: UITextField!
    @IBOutlet weak var tfPrecio: UITextField!
    @IBOutlet weak var tfDescuento: UITextField!
    @IBOutlet weak var tfNeto: UITextField!
    
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        self.tfNombre.text = pCurso.Nombre
        self.tfApellido.text = pCurso.Apellido
        self.tfDni.text = pCurso.Dni
        self.tfCurso.text = pCurso.Curso
        self.tfPrecio.text = pCurso.Precio
        self.tfDescuento.text = pCurso.Descuento
        self.tfNeto.text = pCurso.Neto
        
        
        
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
